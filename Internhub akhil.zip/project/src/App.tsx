import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import StickyBanner from './components/StickyBanner';
import MainContent from './components/MainContent';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleMenuClick = () => {
    setSidebarOpen(true);
  };

  const handleSidebarClose = () => {
    setSidebarOpen(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={handleSidebarClose} />
      
      {/* Main Content Area */}
      <div className="flex-1 lg:ml-0">
        {/* Mobile Header */}
        <Header onMenuClick={handleMenuClick} />
        
        {/* Main Content */}
        <MainContent />
        
        {/* Sticky Banner */}
        <StickyBanner />
      </div>
    </div>
  );
}

export default App;